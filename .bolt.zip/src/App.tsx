import React, { useState, useCallback, useEffect } from 'react';
import { Grid } from './components/Grid';
import { GridSizeSelector } from './components/GridSizeSelector';
import { GripVertical, GripHorizontal, Undo2, Printer, RotateCcw, Lock, Unlock, Power } from 'lucide-react';

interface CellValue {
  mainValue?: number;
  smallValues: Set<number>;
  isKey?: boolean;
}

interface GameState {
  cellValues: Record<string, CellValue>;
  walls: Set<string>;
}

function App() {
  const [gridSize, setGridSize] = useState({ rows: 4, cols: 4 });
  const [walls, setWalls] = useState<Set<string>>(new Set());
  const [selectedNumber, setSelectedNumber] = useState<number | null>(null);
  const [selectedSmallNumber, setSelectedSmallNumber] = useState<number | null>(null);
  const [cellValues, setCellValues] = useState<Record<string, CellValue>>({});
  const [history, setHistory] = useState<GameState[]>([]);
  const [currentIndex, setCurrentIndex] = useState(-1);
  const [isLocked, setIsLocked] = useState(false);
  const [isSettingKeys, setIsSettingKeys] = useState(true);

  const saveState = useCallback(() => {
    // Only save state if we're in unlock mode
    if (isLocked) return;
    
    const newState: GameState = {
      cellValues: JSON.parse(JSON.stringify(cellValues, (key, value) => {
        if (value instanceof Set) return Array.from(value);
        return value;
      })),
      walls: new Set(walls)
    };

    setHistory(prev => {
      const newHistory = prev.slice(0, currentIndex + 1);
      return [...newHistory, newState];
    });
    setCurrentIndex(prev => prev + 1);
  }, [cellValues, walls, currentIndex, isLocked]);

  const undo = useCallback(() => {
    if (currentIndex > 0) {
      const previousState = history[currentIndex - 1];
      setCellValues(
        JSON.parse(JSON.stringify(previousState.cellValues), (key, value) => {
          if (Array.isArray(value)) return new Set(value);
          return value;
        })
      );
      setWalls(new Set(previousState.walls));
      setCurrentIndex(prev => prev - 1);
    }
  }, [currentIndex, history]);

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
      e.preventDefault();
      undo();
    }
  }, [undo]);

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  const handleWallToggle = useCallback((wallId: string) => {
    if (isLocked) return;
    setWalls(prev => {
      const newWalls = new Set(prev);
      if (newWalls.has(wallId)) {
        newWalls.delete(wallId);
      } else {
        newWalls.add(wallId);
      }
      return newWalls;
    });
    saveState();
  }, [saveState, isLocked]);

  const handleCellClick = useCallback((cellId: string) => {
    if (isLocked && cellValues[cellId]?.isKey) return; // Prevent modifying key numbers when locked
    
    if (selectedNumber !== null) {
      setCellValues(prev => {
        const newValues = { ...prev };
        const currentValue = newValues[cellId] || { smallValues: new Set() };
        
        if (currentValue.mainValue === selectedNumber) {
          delete newValues[cellId];
        } else {
          newValues[cellId] = {
            mainValue: selectedNumber,
            smallValues: new Set(),
            isKey: !isLocked && isSettingKeys
          };
        }
        return newValues;
      });
      
      // Only save state if we're in unlock mode
      if (!isLocked) {
        saveState();
      }
    } else if (selectedSmallNumber !== null && (!isSettingKeys || isLocked)) {
      setCellValues(prev => {
        const newValues = { ...prev };
        const currentValue = newValues[cellId] || { smallValues: new Set() };
        if (currentValue.isKey) return newValues; // Don't modify key numbers
        
        const newSmallValues = new Set(currentValue.smallValues);
        
        if (newSmallValues.has(selectedSmallNumber)) {
          newSmallValues.delete(selectedSmallNumber);
        } else {
          newSmallValues.add(selectedSmallNumber);
        }
        
        if (newSmallValues.size === 0 && !currentValue.mainValue) {
          delete newValues[cellId];
        } else {
          newValues[cellId] = {
            ...currentValue,
            smallValues: newSmallValues
          };
        }
        
        return newValues;
      });
      
      // Only save state if we're in unlock mode
      if (!isLocked) {
        saveState();
      }
    }
  }, [selectedNumber, selectedSmallNumber, saveState, isLocked, isSettingKeys]);

  const handlePrint = useCallback(() => {
    window.print();
  }, []);

  const handleReset = useCallback(() => {
    // Keep only key numbers when resetting
    setCellValues(prev => {
      const newValues: Record<string, CellValue> = {};
      Object.entries(prev).forEach(([key, value]) => {
        if (value.isKey) {
          newValues[key] = value;
        }
      });
      return newValues;
    });
    
    // Only save state if we're in unlock mode
    if (!isLocked) {
      saveState();
    }
  }, [saveState, isLocked]);

  const handleStop = useCallback(() => {
    setIsLocked(false);
    setIsSettingKeys(true);
    setCellValues({});
    setWalls(new Set());
    saveState();
  }, [saveState]);

  const handleLock = useCallback(() => {
    setIsLocked(prev => !prev);
    setIsSettingKeys(false);
  }, []);

  useEffect(() => {
    // Initialize history with empty state
    saveState();
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const renderNumberButtons = () => (
    <div className="flex gap-4 justify-center">
      {[1, 2, 3, 4, 5].map(number => {
        const isSelected = selectedNumber === number;
        const isSmallSelected = selectedSmallNumber === number;
        return (
          <div key={number} className="flex flex-col items-center">
            <button
              className={`rounded-md font-semibold transition-colors border-2 border-gray-600 mb-2 w-13 h-13 text-xl
                ${isSelected
                  ? 'bg-blue-500 text-white border-blue-600' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              onClick={() => {
                setSelectedNumber(isSelected ? null : number);
                setSelectedSmallNumber(null);
              }}
            >
              {number}
            </button>
            <button
              className={`rounded-md font-semibold transition-colors border-2 border-gray-600 w-8 h-8 text-sm
                ${isSmallSelected
                  ? 'bg-green-200 text-gray-700 border-green-400'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
              onClick={() => {
                setSelectedSmallNumber(isSmallSelected ? null : number);
                setSelectedNumber(null);
              }}
              disabled={!isLocked && isSettingKeys}
            >
              {number}
            </button>
          </div>
        );
      })}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col">
      <header className="bg-white shadow-md print:shadow-none">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex flex-col items-center mb-4">
            <h1 className="text-4xl font-bold text-gray-800 text-center">TECTONIC GRID</h1>
          </div>
          
          <div className="flex items-center justify-between">
            <GridSizeSelector 
              value={gridSize}
              onChange={setGridSize}
              disabled={isLocked}
            />
            
            <div className="flex gap-4 print:hidden">
              <button
                className="p-2 rounded-md hover:bg-gray-100 text-gray-700"
                onClick={undo}
                disabled={currentIndex <= 0}
                title="Undo (Ctrl+Z)"
              >
                <Undo2 className="w-5 h-5" />
              </button>
              
              <button
                className="p-2 rounded-md hover:bg-gray-100 text-gray-700"
                onClick={handleReset}
                title="Reset Grid"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
              
              <button
                className={`p-2 rounded-md hover:bg-gray-100 text-gray-700 ${
                  isLocked ? 'bg-gray-200' : ''
                }`}
                onClick={handleLock}
                title={isLocked ? "Unlock Grid" : "Lock Grid"}
              >
                {isLocked ? (
                  <Lock className="w-5 h-5" />
                ) : (
                  <Unlock className="w-5 h-5" />
                )}
              </button>
              
              <button
                className="p-2 rounded-md hover:bg-gray-100 text-gray-700"
                onClick={handleStop}
                title="Stop"
              >
                <Power className="w-5 h-5" />
              </button>
              
              <button
                className="p-2 rounded-md hover:bg-gray-100 text-gray-700"
                onClick={handlePrint}
                title="Print"
              >
                <Printer className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </header>
      
      <main className="flex-grow max-w-7xl mx-auto px-4 py-8 flex justify-center">
        <div className="bg-gray-50 p-8 print:p-0 print:bg-white">
          <Grid 
            rows={gridSize.rows}
            cols={gridSize.cols}
            walls={walls}
            onWallToggle={handleWallToggle}
            cellValues={cellValues}
            onCellClick={handleCellClick}
          />
        </div>
      </main>
      
      <footer className="bg-white shadow-inner py-4 print:hidden">
        <div className="max-w-7xl mx-auto px-4">
          {renderNumberButtons()}
        </div>
      </footer>
    </div>
  );
}

export default App;